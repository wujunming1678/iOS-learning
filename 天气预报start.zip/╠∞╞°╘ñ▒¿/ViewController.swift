//
//  ViewController.swift
//  天气预报
//
//  Created by 吴俊明 on 2022/10/8.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var info: UILabel!
    @IBOutlet weak var direcPower: UILabel!
    @IBOutlet weak var temperture: UILabel!
    @IBOutlet weak var humidity: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var weathers:[Future] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.rowHeight = 75
        weatherModel.getWeather { welcome in
            let time = welcome.result.realtime
            self.weathers = welcome.result.future
           
            DispatchQueue.main.async {
                self.info.text = "今日天气\(time.info)"
                self.direcPower.text = "今日风速\(time.direct) \(time.power)"
                self.temperture.text = "今日温度\(time.temperature)"
                self.humidity.text = "今日湿度\(time.humidity)"
                self.tableView.reloadData()
            }
        }
    }
}
extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weathers.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "weather", for: indexPath) as! WeatherTableViewCell
        let model = weathers[indexPath.row]
        cell.setData(model: model)
        return cell
    }
    
    
}
