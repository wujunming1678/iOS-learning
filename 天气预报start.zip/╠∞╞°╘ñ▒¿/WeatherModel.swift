//
//  WeatherModel.swift
//  天气预报
//
//  Created by 吴俊明 on 2022/10/8.
//

import Foundation
// MARK: - Welcome
struct Welcome: Codable {
    let reason: String
    let result: Result
    let errorCode: Int

    enum CodingKeys: String, CodingKey {
        case reason, result
        case errorCode = "error_code"
    }
}

// MARK: - Result
struct Result: Codable {
    let city: String
    let realtime: Realtime
    let future: [Future]
}

// MARK: - Future
struct Future: Codable {
    let date, temperature, weather: String
    let wid: Wid
    let direct: String
}

// MARK: - Wid
struct Wid: Codable {
    let day, night: String
}

// MARK: - Realtime
struct Realtime: Codable {
    let temperature, humidity, info, wid: String
    let direct, power, aqi: String
}
struct weatherModel {
    static func getWeather(completionHander: @escaping(Welcome) -> Void){
        if let url = URL(string: "http://apis.juhe.cn/simpleWeather/query?city=%E8%8A%9C%E6%B9%96&key=95a8bdfb7fde92585c283bba3c50c36a"){
            let request = URLRequest(url: url)
            let config = URLSessionConfiguration.default
            let session = URLSession(configuration: config)
            let task = session.dataTask(with: request){data, response,error in
                if error == nil, let data = data{
//                    print(String(data:data,encoding: .utf8))
                            do{
                                let welcome = try JSONDecoder().decode(Welcome.self, from: data)
                                    completionHander(welcome)
//                        let time = welcome.result.realtime
//                        self.weathers = welcome.result.future
                       
                 
                        
                            }catch{
                        
                        }
                    }
                }
            task.resume()
            
            }else {
                print("url不合法")
        }
    }
}
