//
//  WeatherTableViewCell.swift
//  天气预报
//
//  Created by 吴俊明 on 2022/10/8.
//

import UIKit

class WeatherTableViewCell: UITableViewCell {
    @IBOutlet weak var data: UILabel!
    @IBOutlet weak var direct: UILabel!
    @IBOutlet weak var temperture: UILabel!
    @IBOutlet weak var weather: UILabel!
    func setData(model:Future)  {
        
        data.text = model.date
        weather.text = model.weather
       temperture.text = model.temperature
        direct.text = model.direct
    }
    
    
    
    
    
}
