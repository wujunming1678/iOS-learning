//
//  ViewController.swift
//  topNews
//
//  Created by 吴俊明 on 2022/10/11.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var data:[Datum] = []
    var tpye = "top"

    fileprivate func getNews() {
        NewsModel.getNews(tpye: tpye){ Welcome in
            
            self.data = Welcome.result.data
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableView.rowHeight = 165.0
        tableView.dataSource = self
        tableView.delegate = self
        getNews()
    }
 
    @IBAction func valueChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            tpye = "top"
        case 1:
            tpye = "keji"
        case 2:
            tpye = "tiyu"
        case 3:
            tpye = "junshi"
        case 4:
            tpye = "jiangkang"
        default:
            break
        }
    getNews()
        
    }
}
extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "news", for: indexPath) as! newsCellTableViewCell
        let model = data[indexPath.row]
        
        cell.setModel(model: model)
        return cell
    }
}
extension ViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let model = data[indexPath.row]
        let detailsVC = DetailsViewController()
        detailsVC.title = model.title
        detailsVC.urlString = model.url
        navigationController?.pushViewController(detailsVC, animated: true)
    }
}
