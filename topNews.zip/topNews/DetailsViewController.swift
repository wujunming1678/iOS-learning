//
//  DetailsViewController.swift
//  topNews
//
//  Created by 吴俊明 on 2022/10/11.
//

import UIKit
import WebKit


class DetailsViewController: UIViewController {
    var urlString:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        if let urlString = urlString, let url = URL(string: urlString){
            let requset = URLRequest(url: url)
            let webView = WKWebView(frame: UIScreen.main.bounds)
            webView.load(requset)
            view.addSubview(webView)
        }
        
    }
    

}
