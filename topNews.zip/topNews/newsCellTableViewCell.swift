//
//  newsCellTableViewCell.swift
//  topNews
//
//  Created by 吴俊明 on 2022/10/11.
//

import UIKit

class newsCellTableViewCell: UITableViewCell {

    @IBOutlet weak var newsImage: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var authorName: UILabel!
    @IBOutlet weak var data: UILabel!
    func setModel(model: Datum) {
        title.text = model.title
        authorName.text = model.authorName
        data.text = model.date
        newsImage.kf.setImage(with: URL(string: model.thumbnailPicS), placeholder:UIImage(systemName: "paperplane"))
    }
}
