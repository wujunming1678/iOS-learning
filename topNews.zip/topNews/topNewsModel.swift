//
//  topNewsModel.swift
//  topNews
//
//  Created by 吴俊明 on 2022/10/11.
//

import Foundation
// MARK: - Welcome
struct Welcome: Codable {
    let reason: String
    let result: Result2
    let errorCode: Int

    enum CodingKeys: String, CodingKey {
        case reason, result
        case errorCode = "error_code"
    }
}

// MARK: - Result
struct Result2: Codable {
    let stat: String
    let data: [Datum]
    let page, pageSize: String
}

// MARK: - Datum
struct Datum: Codable {
    let uniquekey, title, date: String
    let category: String
    let authorName: String
    let url: String
    let thumbnailPicS: String
    let isContent: String
    let thumbnailPicS02, thumbnailPicS03: String?

    enum CodingKeys: String, CodingKey {
        case uniquekey, title, date, category
        case authorName = "author_name"
        case url
        case thumbnailPicS = "thumbnail_pic_s"
        case isContent = "is_content"
        case thumbnailPicS02 = "thumbnail_pic_s02"
        case thumbnailPicS03 = "thumbnail_pic_s03"
    }
}

struct NewsModel {
    static func getNews(tpye: String,completionHandler:@escaping(Welcome) -> Void) {
        let url = URL(string: "http://v.juhe.cn/toutiao/index?type=\(tpye)&page=&page_size=&is_filter=&key=7989bfa90c6c1f26eff36ddcf9c3bb48")!
       let resquest = URLRequest(url: url)
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with: resquest) { data, response, error in
            if error == nil,let data = data{
                do{
                    let welcome = try JSONDecoder().decode(Welcome.self, from: data)
                    completionHandler(welcome)
                }catch{
                    print(error)
                }
            }
        }
        task.resume()
    }

}
